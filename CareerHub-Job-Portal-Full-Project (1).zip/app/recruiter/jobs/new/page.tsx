"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewJob() {
  const [form,setForm] = useState({
    title:"",company:"",location:"",jobType:"Full-time",skills:"",salary:"",description:""
  });
  const [error,setError]=useState("");
  const router=useRouter();

  function update(k:string,v:string){setForm({...form,[k]:v});}

  async function submit(e:React.FormEvent){
    e.preventDefault();
    const res=await fetch("/api/jobs",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
    const data=await res.json();
    if(!res.ok) return setError(data.error||"Could not create job");
    router.push("/recruiter");
    router.refresh();
  }

  return (
    <div className="container">
      <form className="form" onSubmit={submit}>
        <h1>Create Job Listing</h1>
        {error && <div className="error">{error}</div>}
        <label>Job Title</label><input required value={form.title} onChange={e=>update("title",e.target.value)}/>
        <label>Company</label><input required value={form.company} onChange={e=>update("company",e.target.value)}/>
        <label>Location</label><input required value={form.location} onChange={e=>update("location",e.target.value)}/>
        <label>Job Type</label><select value={form.jobType} onChange={e=>update("jobType",e.target.value)}><option>Full-time</option><option>Part-time</option><option>Internship</option><option>Contract</option></select>
        <label>Skills</label><input required placeholder="React, Node.js, PostgreSQL" value={form.skills} onChange={e=>update("skills",e.target.value)}/>
        <label>Salary</label><input value={form.salary} onChange={e=>update("salary",e.target.value)} placeholder="4 - 6 LPA"/>
        <label>Description</label><textarea required value={form.description} onChange={e=>update("description",e.target.value)}/>
        <button className="btn">Publish Job</button>
      </form>
    </div>
  );
}
