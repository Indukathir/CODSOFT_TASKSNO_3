import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";

export default async function RecruiterDashboard() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "RECRUITER") redirect("/dashboard");

  const jobs = await prisma.job.findMany({
    where: { recruiterId: session.id },
    include: { _count: { select: { applications: true } } },
    orderBy: { createdAt: "desc" }
  });

  const applications = await prisma.application.findMany({
    where: { job: { recruiterId: session.id } },
    include: { job: { select: { title: true } }, candidate: { select: { name: true, email: true, resumeUrl: true } } },
    orderBy: { createdAt: "desc" }
  });

  return (
    <div className="container">
      <h1>Recruiter Dashboard</h1>
      <div className="stat-grid">
        <div className="stat">My Jobs<strong>{jobs.length}</strong></div>
        <div className="stat">Applications<strong>{applications.length}</strong></div>
        <div className="stat">Shortlisted<strong>{applications.filter(a=>a.status==="SHORTLISTED").length}</strong></div>
      </div>

      <h2 className="section-title">Post a Job</h2>
      <Link href="/recruiter/jobs/new" className="btn">+ Create Job</Link>

      <h2 className="section-title">My Job Listings</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Title</th><th>Location</th><th>Type</th><th>Applications</th></tr></thead>
          <tbody>{jobs.map(j => <tr key={j.id}><td>{j.title}</td><td>{j.location}</td><td>{j.jobType}</td><td>{j._count.applications}</td></tr>)}</tbody>
        </table>
      </div>

      <h2 className="section-title">Candidate Applications</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Candidate</th><th>Job</th><th>Status</th><th>Resume</th><th>Action</th></tr></thead>
          <tbody>
            {applications.map(a => (
              <tr key={a.id}>
                <td>{a.candidate.name}<br/><span className="muted">{a.candidate.email}</span></td>
                <td>{a.job.title}</td>
                <td><span className="badge">{a.status}</span></td>
                <td>{a.resumeUrl ? <a href={a.resumeUrl} target="_blank">View</a> : "—"}</td>
                <td><ApplicationStatus applicationId={a.id} current={a.status} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ApplicationStatus({ applicationId, current }: { applicationId: string; current: string }) {
  return (
    <form action={`/api/applications/${applicationId}/status`} method="post">
      <select name="status" defaultValue={current} onChange={(e) => e.currentTarget.form?.requestSubmit()}>
        <option>APPLIED</option><option>REVIEWING</option><option>SHORTLISTED</option><option>REJECTED</option><option>HIRED</option>
      </select>
    </form>
  );
}
