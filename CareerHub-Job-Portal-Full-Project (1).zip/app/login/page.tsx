"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/auth/login", {
      method: "POST", headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (!res.ok) return setError(data.error || "Login failed");
    router.push(data.role === "RECRUITER" ? "/recruiter" : "/dashboard");
    router.refresh();
  }

  return (
    <div className="container">
      <form className="form" onSubmit={submit}>
        <h1>Login</h1>
        {error && <div className="error">{error}</div>}
        <label>Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} />
        <label>Password</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} />
        <button className="btn">Login</button>
        <p>New user? <Link href="/register">Create an account</Link></p>
      </form>
    </div>
  );
}
