import { prisma } from "@/lib/prisma";
import JobSearch from "@/components/JobSearch";

export default async function JobsPage() {
  const jobs = await prisma.job.findMany({
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true, company: true, location: true, jobType: true, skills: true, salary: true }
  });

  return (
    <div className="container">
      <h1>Find Jobs</h1>
      <p className="muted">Search and apply for opportunities.</p>
      <JobSearch jobs={jobs} />
    </div>
  );
}
