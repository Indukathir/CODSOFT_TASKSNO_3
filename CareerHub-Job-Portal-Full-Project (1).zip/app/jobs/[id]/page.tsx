import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import Link from "next/link";
import { notFound } from "next/navigation";
import ApplyForm from "@/components/ApplyForm";

export default async function JobDetail({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const job = await prisma.job.findUnique({
    where: { id },
    include: { recruiter: { select: { name: true, email: true } } }
  });
  if (!job) notFound();

  const session = await getSession();

  return (
    <div className="container">
      <div className="detail">
        <span className="badge">{job.jobType}</span>
        <h1>{job.title}</h1>
        <h3>{job.company}</h3>
        <p className="muted">📍 {job.location} &nbsp; • &nbsp; Posted by {job.recruiter.name}</p>
        {job.salary && <p><strong>Salary:</strong> {job.salary}</p>}
        <h2>Job Description</h2>
        <p style={{whiteSpace:"pre-wrap"}}>{job.description}</p>
        <h2>Required Skills</h2>
        <p>{job.skills}</p>

        {session?.role === "CANDIDATE" ? (
          <ApplyForm jobId={job.id} />
        ) : !session ? (
          <p><Link className="btn" href="/login">Login as candidate to apply</Link></p>
        ) : (
          <p className="muted">Recruiter accounts cannot apply for jobs.</p>
        )}
      </div>
    </div>
  );
}
