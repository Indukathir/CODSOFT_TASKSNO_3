import "./globals.css";
import Link from "next/link";
import { getSession } from "@/lib/auth";
import LogoutButton from "@/components/LogoutButton";

export const metadata = {
  title: "CareerHub - Job Portal",
  description: "Modern recruitment platform for candidates and recruiters"
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();

  return (
    <html lang="en">
      <body>
        <header className="navbar">
          <div className="nav-inner">
            <Link href="/" className="brand">Career<span>Hub</span></Link>
            <nav>
              <Link href="/jobs">Jobs</Link>
              {session?.role === "CANDIDATE" && <Link href="/dashboard">My Applications</Link>}
              {session?.role === "RECRUITER" && <Link href="/recruiter">Recruiter Dashboard</Link>}
              {!session ? (
                <>
                  <Link href="/login">Login</Link>
                  <Link href="/register" className="btn small">Register</Link>
                </>
              ) : (
                <span className="nav-user">
                  Hi, {session.name}
                  <LogoutButton />
                </span>
              )}
            </nav>
          </div>
        </header>
        <main>{children}</main>
        <footer className="footer">© 2026 CareerHub • Job Portal</footer>
      </body>
    </html>
  );
}
