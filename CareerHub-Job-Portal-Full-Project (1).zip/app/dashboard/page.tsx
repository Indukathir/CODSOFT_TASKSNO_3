import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { redirect } from "next/navigation";

export default async function Dashboard() {
  const session = await getSession();
  if (!session) redirect("/login");
  if (session.role !== "CANDIDATE") redirect("/recruiter");

  const user = await prisma.user.findUnique({
    where: { id: session.id },
    include: {
      applications: {
        include: { job: { select: { title: true, company: true, location: true } },
        },
        orderBy: { createdAt: "desc" }
      }
    }
  });

  if (!user) redirect("/login");

  return (
    <div className="container">
      <h1>Candidate Dashboard</h1>
      <div className="cards">
        <div className="card"><h3>Profile</h3><p>{user.name}</p><p>{user.email}</p><p>{user.skills || "Add your skills in your profile."}</p></div>
        <div className="card"><h3>Resume</h3><p>{user.resumeUrl ? "Resume uploaded" : "Resume can be uploaded while applying."}</p></div>
      </div>

      <h2 className="section-title">My Applications</h2>
      <div className="table-wrap">
        <table>
          <thead><tr><th>Job</th><th>Company</th><th>Location</th><th>Status</th><th>Applied</th></tr></thead>
          <tbody>
            {user.applications.map(a => (
              <tr key={a.id}>
                <td>{a.job.title}</td><td>{a.job.company}</td><td>{a.job.location}</td>
                <td><span className="badge">{a.status}</span></td>
                <td>{a.createdAt.toLocaleDateString()}</td>
              </tr>
            ))}
            {user.applications.length === 0 && <tr><td colSpan={5}>No applications yet.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
