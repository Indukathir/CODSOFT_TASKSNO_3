import Link from "next/link";
import { prisma } from "@/lib/prisma";

export default async function Home() {
  const jobCount = await prisma.job.count();
  const candidateCount = await prisma.user.count({ where: { role: "CANDIDATE" } });

  return (
    <>
      <section className="hero">
        <div className="hero-inner">
          <h1>Find your next opportunity with CareerHub</h1>
          <p>A centralized recruitment platform where candidates discover jobs, apply online and track applications while recruiters manage hiring in one place.</p>
          <Link href="/jobs" className="btn light">Explore Jobs</Link>
        </div>
      </section>
      <div className="container">
        <h2>Why CareerHub?</h2>
        <div className="cards">
          <div className="card"><h3>🔎 Job Search</h3><p>Search jobs by title, skill, location and job type.</p></div>
          <div className="card"><h3>📄 Easy Applications</h3><p>Apply online with a resume and cover letter.</p></div>
          <div className="card"><h3>📊 Application Tracking</h3><p>Track APPLIED, REVIEWING, SHORTLISTED, REJECTED and HIRED status.</p></div>
          <div className="card"><h3>👥 Recruiter Dashboard</h3><p>Publish jobs and manage candidates through a centralized workflow.</p></div>
        </div>
        <div className="stat-grid section-title">
          <div className="stat">Active jobs<strong>{jobCount}</strong></div>
          <div className="stat">Registered candidates<strong>{candidateCount}</strong></div>
        </div>
      </div>
    </>
  );
}
