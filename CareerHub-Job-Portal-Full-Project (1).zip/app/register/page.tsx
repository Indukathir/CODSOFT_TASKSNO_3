"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Register() {
  const [form, setForm] = useState({name:"",email:"",password:"",role:"CANDIDATE"});
  const [error, setError] = useState("");
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/auth/register", {
      method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(form)
    });
    const data = await res.json();
    if (!res.ok) return setError(data.error || "Registration failed");
    router.push(data.role === "RECRUITER" ? "/recruiter" : "/dashboard");
    router.refresh();
  }

  return (
    <div className="container">
      <form className="form" onSubmit={submit}>
        <h1>Create CareerHub Account</h1>
        {error && <div className="error">{error}</div>}
        <label>Name</label><input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
        <label>Email</label><input required type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/>
        <label>Password</label><input required minLength={6} type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/>
        <label>Account Type</label>
        <select value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
          <option value="CANDIDATE">Candidate / Job Seeker</option>
          <option value="RECRUITER">Recruiter / Company</option>
        </select>
        <button className="btn">Register</button>
        <p>Already registered? <Link href="/login">Login</Link></p>
      </form>
    </div>
  );
}
