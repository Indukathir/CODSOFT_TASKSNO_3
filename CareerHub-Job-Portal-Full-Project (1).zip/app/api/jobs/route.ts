import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "RECRUITER") {
    return NextResponse.json({ error: "Recruiter login required." }, { status: 401 });
  }

  try {
    const body = await req.json();
    const required = ["title","company","location","jobType","skills","description"];
    if (required.some(k => !body[k])) return NextResponse.json({ error: "Please fill all required fields." }, { status: 400 });

    const job = await prisma.job.create({
      data: {
        title: body.title, company: body.company, location: body.location,
        jobType: body.jobType, skills: body.skills, description: body.description,
        salary: body.salary || null, recruiterId: session.id
      }
    });
    return NextResponse.json(job, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not create job." }, { status: 500 });
  }
}
