import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import fs from "fs/promises";
import path from "path";

export async function POST(req: Request) {
  const session = await getSession();
  if (!session || session.role !== "CANDIDATE") {
    return NextResponse.json({ error: "Candidate login required." }, { status: 401 });
  }

  try {
    const form = await req.formData();
    const jobId = String(form.get("jobId") || "");
    const coverLetter = String(form.get("coverLetter") || "");
    const resume = form.get("resume");

    const job = await prisma.job.findUnique({ where: { id: jobId } });
    if (!job) return NextResponse.json({ error: "Job not found." }, { status: 404 });

    const existing = await prisma.application.findUnique({
      where: { jobId_candidateId: { jobId, candidateId: session.id } }
    });
    if (existing) return NextResponse.json({ error: "You already applied for this job." }, { status: 409 });

    let resumeUrl: string | null = null;

    if (resume instanceof File && resume.size > 0) {
      if (resume.size > 5 * 1024 * 1024) {
        return NextResponse.json({ error: "Resume must be below 5 MB." }, { status: 400 });
      }
      const allowed = ["application/pdf", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document"];
      if (!allowed.includes(resume.type)) {
        return NextResponse.json({ error: "Only PDF, DOC and DOCX files are allowed." }, { status: 400 });
      }
      const dir = path.join(process.cwd(), "public", "uploads");
      await fs.mkdir(dir, { recursive: true });
      const safeName = `${session.id}-${Date.now()}-${resume.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
      await fs.writeFile(path.join(dir, safeName), Buffer.from(await resume.arrayBuffer()));
      resumeUrl = `/uploads/${safeName}`;

      await prisma.user.update({ where: { id: session.id }, data: { resumeUrl } });
    }

    const application = await prisma.application.create({
      data: { jobId, candidateId: session.id, coverLetter, resumeUrl }
    });

    return NextResponse.json(application, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Could not submit application." }, { status: 500 });
  }
}
