import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";

const statuses = ["APPLIED","REVIEWING","SHORTLISTED","REJECTED","HIRED"];

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const session = await getSession();
  if (!session || session.role !== "RECRUITER") {
    return NextResponse.redirect(new URL("/login", req.url));
  }

  const { id } = await params;
  const form = await req.formData();
  const status = String(form.get("status"));

  if (!statuses.includes(status)) return NextResponse.json({ error: "Invalid status." }, { status: 400 });

  const application = await prisma.application.findUnique({
    where: { id },
    include: { job: true }
  });

  if (!application || application.job.recruiterId !== session.id) {
    return NextResponse.json({ error: "Application not found." }, { status: 404 });
  }

  await prisma.application.update({ where: { id }, data: { status: status as any } });
  return NextResponse.redirect(new URL("/recruiter", req.url));
}
