import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { createSession } from "@/lib/auth";
import bcrypt from "bcryptjs";

export async function POST(req: Request) {
  try {
    const { name, email, password, role } = await req.json();
    if (!name || !email || !password || !["CANDIDATE","RECRUITER"].includes(role)) {
      return NextResponse.json({ error: "All fields are required." }, { status: 400 });
    }
    if (password.length < 6) return NextResponse.json({ error: "Password must be at least 6 characters." }, { status: 400 });

    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return NextResponse.json({ error: "Email already registered." }, { status: 409 });

    const user = await prisma.user.create({
      data: { name, email: email.toLowerCase(), passwordHash: await bcrypt.hash(password, 10), role }
    });

    await createSession({ id: user.id, role: user.role, email: user.email, name: user.name });
    return NextResponse.json({ role: user.role });
  } catch {
    return NextResponse.json({ error: "Registration failed." }, { status: 500 });
  }
}
