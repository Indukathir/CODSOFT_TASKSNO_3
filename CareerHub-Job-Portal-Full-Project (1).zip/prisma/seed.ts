import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  const passwordHash = await bcrypt.hash("Password123", 10);

  const recruiter = await prisma.user.upsert({
    where: { email: "recruiter@careerhub.com" },
    update: {},
    create: {
      name: "CareerHub Recruiter",
      email: "recruiter@careerhub.com",
      passwordHash,
      role: Role.RECRUITER,
      location: "Chennai"
    }
  });

  await prisma.user.upsert({
    where: { email: "candidate@careerhub.com" },
    update: {},
    create: {
      name: "Demo Candidate",
      email: "candidate@careerhub.com",
      passwordHash,
      role: Role.CANDIDATE,
      location: "Chennai",
      skills: "JavaScript, React, Node.js, SQL"
    }
  });

  const count = await prisma.job.count({ where: { recruiterId: recruiter.id } });

  if (count === 0) {
    await prisma.job.createMany({
      data: [
        {
          title: "Junior Full Stack Developer",
          company: "CareerHub Technologies",
          location: "Chennai / Hybrid",
          jobType: "Full-time",
          description: "Build responsive web applications, REST APIs and database-backed features with the development team.",
          skills: "JavaScript, React, Node.js, PostgreSQL",
          salary: "4 - 6 LPA",
          recruiterId: recruiter.id
        },
        {
          title: "Java Software Engineer",
          company: "Tech Solutions Pvt Ltd",
          location: "Bangalore",
          jobType: "Full-time",
          description: "Develop and maintain Java services and work with SQL databases and REST APIs.",
          skills: "Java, Spring Boot, SQL, REST API",
          salary: "5 - 8 LPA",
          recruiterId: recruiter.id
        }
      ]
    });
  }

  console.log("Seed complete.");
  console.log("Recruiter: recruiter@careerhub.com / Password123");
  console.log("Candidate: candidate@careerhub.com / Password123");
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect());
