import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";

const secret = new TextEncoder().encode(
  process.env.JWT_SECRET || "development-secret-change-me"
);

export type Session = {
  id: string;
  role: "CANDIDATE" | "RECRUITER";
  email: string;
  name: string;
};

export async function createSession(session: Session) {
  const token = await new SignJWT(session)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(secret);

  const cookieStore = await cookies();
  cookieStore.set("careerhub_session", token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7,
    path: "/"
  });
}

export async function getSession(): Promise<Session | null> {
  const token = (await cookies()).get("careerhub_session")?.value;
  if (!token) return null;

  try {
    const { payload } = await jwtVerify(token, secret);
    return {
      id: String(payload.id),
      role: String(payload.role) as Session["role"],
      email: String(payload.email),
      name: String(payload.name)
    };
  } catch {
    return null;
  }
}

export async function clearSession() {
  (await cookies()).delete("careerhub_session");
}
