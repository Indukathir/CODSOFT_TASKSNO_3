"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function ApplyForm({ jobId }: { jobId: string }) {
  const [coverLetter, setCoverLetter] = useState("");
  const [resume, setResume] = useState<File | null>(null);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage("");
    const form = new FormData();
    form.append("jobId", jobId);
    form.append("coverLetter", coverLetter);
    if (resume) form.append("resume", resume);

    const res = await fetch("/api/applications", { method: "POST", body: form });
    const data = await res.json();
    setLoading(false);

    if (!res.ok) return setMessage(data.error || "Application failed");
    setMessage("Application submitted successfully!");
    setTimeout(() => router.push("/dashboard"), 700);
  }

  return (
    <form className="form" onSubmit={submit}>
      <h2>Apply for this job</h2>
      {message && <div className={message.includes("success") ? "success" : "error"}>{message}</div>}
      <label>Cover Letter</label>
      <textarea value={coverLetter} onChange={e => setCoverLetter(e.target.value)} placeholder="Tell the recruiter why you are suitable..." />
      <label>Resume (PDF/DOC/DOCX)</label>
      <input type="file" accept=".pdf,.doc,.docx" onChange={e => setResume(e.target.files?.[0] || null)} />
      <button className="btn" disabled={loading}>{loading ? "Submitting..." : "Submit Application"}</button>
    </form>
  );
}
