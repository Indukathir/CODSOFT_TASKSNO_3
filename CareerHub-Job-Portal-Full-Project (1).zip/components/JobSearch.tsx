"use client";
import { useState } from "react";
import Link from "next/link";

type Job = {
  id: string; title: string; company: string; location: string;
  jobType: string; skills: string; salary?: string | null;
};

export default function JobSearch({ jobs }: { jobs: Job[] }) {
  const [q, setQ] = useState("");
  const [location, setLocation] = useState("");
  const [type, setType] = useState("");

  const filtered = jobs.filter(j => {
    const text = `${j.title} ${j.company} ${j.skills}`.toLowerCase();
    return text.includes(q.toLowerCase()) &&
      j.location.toLowerCase().includes(location.toLowerCase()) &&
      (!type || j.jobType === type);
  });

  return (
    <>
      <div className="filters">
        <input placeholder="Search job, company or skill" value={q} onChange={e => setQ(e.target.value)} />
        <input placeholder="Location" value={location} onChange={e => setLocation(e.target.value)} />
        <select value={type} onChange={e => setType(e.target.value)}>
          <option value="">All types</option>
          <option>Full-time</option><option>Part-time</option><option>Internship</option><option>Contract</option>
        </select>
        <span className="badge">{filtered.length} jobs</span>
      </div>
      <div className="job-grid">
        {filtered.map(job => (
          <article className="card job-card" key={job.id}>
            <span className="badge">{job.jobType}</span>
            <h3>{job.title}</h3>
            <p><strong>{job.company}</strong></p>
            <p className="muted">📍 {job.location}</p>
            <p className="muted">Skills: {job.skills}</p>
            {job.salary && <p><strong>Salary:</strong> {job.salary}</p>}
            <Link className="btn" href={`/jobs/${job.id}`}>View & Apply</Link>
          </article>
        ))}
      </div>
      {filtered.length === 0 && <p>No jobs found.</p>}
    </>
  );
}
