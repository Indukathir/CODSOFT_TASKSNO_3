# CareerHub - Full Stack Job Portal

A college/internship-ready MVP based on the Task 3 requirements.

## Features

### Candidate
- Register/login
- Search jobs
- Filter by location/job type
- View job details
- Apply with cover letter
- Upload PDF/DOC/DOCX resume
- Track application status

### Recruiter
- Register/login
- Create and publish jobs
- View job listings
- View candidates who applied
- Update application status:
  APPLIED -> REVIEWING -> SHORTLISTED -> REJECTED / HIRED

## Tech Stack

- Next.js (React + Node.js server)
- PostgreSQL
- Prisma ORM
- JWT HTTP-only cookie authentication
- bcrypt password hashing
- Local file upload for development

Cloud storage can be added later using AWS S3, Cloudinary, Supabase Storage or another object-storage provider.

## Run on Windows

1. Install Node.js LTS and Docker Desktop.
2. Open PowerShell in this folder.
3. Create environment file:
   Copy-Item .env.example .env
4. Start PostgreSQL:
   docker compose up -d
5. Install packages:
   npm install
6. Generate Prisma client:
   npx prisma generate
7. Create database tables:
   npx prisma db push
8. Add demo data:
   npm run db:seed
9. Start:
   npm run dev
10. Open:
   http://localhost:3000

## Demo accounts

Recruiter:
recruiter@careerhub.com
Password123

Candidate:
candidate@careerhub.com
Password123

## Suggested project explanation for viva

"CareerHub is a full-stack recruitment platform. Candidates can register, search and apply for jobs and track application status. Recruiters can publish jobs and manage candidates. Next.js provides the React frontend and Node.js server-side API routes. PostgreSQL stores users, jobs and applications. Prisma provides database access. Authentication uses hashed passwords and an HTTP-only JWT cookie. Resume files are stored in local object-like storage during development and can be migrated to cloud storage for deployment."

## Production improvements

- AWS S3/Cloudinary/Supabase Storage for resumes
- Email notifications
- Pagination and advanced search
- Admin panel
- Company profiles
- Profile editing
- Password reset
- Rate limiting and audit logs
- Deployment with managed PostgreSQL and object storage
